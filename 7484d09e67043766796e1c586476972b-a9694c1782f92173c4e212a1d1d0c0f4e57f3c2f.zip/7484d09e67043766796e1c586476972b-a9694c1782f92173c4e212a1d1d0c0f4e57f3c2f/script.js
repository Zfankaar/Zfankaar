// script.js

document.getElementById('signup-form').addEventListener('submit', function(event) {
    event.preventDefault();
    document.getElementById('signup-section').style.display = 'none';
    document.getElementById('signup-success').style.display = 'block';
    setTimeout(function() {
        document.getElementById('signup-success').style.display = 'none';
        document.getElementById('dashboard').style.display = 'block';
        document.getElementById('nav-menu').style.display = 'flex';
    }, 2000);
});

function toggleNav() {
    var navOptions = document.getElementById('nav-options');
    if (navOptions.style.display === 'block') {
        navOptions.style.display = 'none';
    } else {
        navOptions.style.display = 'block';
    }
}

function showDashboard() {
    document.getElementById('dashboard').style.display = 'block';
    document.getElementById('withdrawal-section').style.display = 'none';
    document.getElementById('watch-videos-section').style.display = 'none';
    document.getElementById('invite-section').style.display = 'none';
}

function showWithdraw() {
    document.getElementById('dashboard').style.display = 'none';
    document.getElementById('withdrawal-section').style.display = 'block';
    document.getElementById('watch-videos-section').style.display = 'none';
    document.getElementById('invite-section').style.display = 'none';
}

function showWatchVideos() {
    document.getElementById('dashboard').style.display = 'none';
    document.getElementById('withdrawal-section').style.display = 'none';
    document.getElementById('watch-videos-section').style.display = 'block';
    document.getElementById('invite-section').style.display = 'none';
}

function showInvite() {
    document.getElementById('dashboard').style.display = 'none';
    document.getElementById('withdrawal-section').style.display = 'none';
    document.getElementById('watch-videos-section').style.display = 'none';
    document.getElementById('invite-section').style.display = 'block';
}

function logout() {
    document.getElementById('dashboard').style.display = 'none';
    document.getElementById('withdrawal-section').style.display = 'none';
    document.getElementById('watch-videos-section').style.display = 'none';
    document.getElementById('invite-section').style.display = 'none';
    document.getElementById('signup-section').style.display = 'block';
    document.getElementById('nav-menu').style.display = 'none';
}

function earnMoney() {
    var earningsAmount = document.getElementById('earnings-amount');
    var currentEarnings = parseInt(earningsAmount.innerText);
    earningsAmount.innerText = currentEarnings + 1;
}
